import { NextResponse } from 'next/server'
import { BRANDS, CATEGORIES } from '@/lib/data'

export async function GET(){
  const urls = [
    '/', '/om','/kontakt','/vilkar','/privatliv','/cookies',
    ...CATEGORIES.map(c=>`/kategori/${c.id}`),
    ...BRANDS.map(b=>`/brand/${b.id}`)
  ]
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map(u=>`<url><loc>https://pandarabatkoder.dk${u}</loc></url>`).join('')}
</urlset>`
  return new NextResponse(xml, { headers: { 'Content-Type': 'application/xml' } })
}
